/*
kotlinc 02KotlinFunctions.kt -include-runtime -d functions.jar
java -jar functions.jar
*/
package learnKotlin

//_________________________________________________________

fun playWithCollectionsInKotlin() {
	val set = hashSetOf(1, 7, 53) 
	val list = arrayListOf(1, 7, 53) 
	val map = hashMapOf(1 to "one", 7 to "seven", 53 to "fifty-three")

    println(set.javaClass)
    println(list.javaClass)
    println(map.javaClass)

    val strings = listOf("first", "second", "fourteenth")
    println(strings.javaClass)
    println(strings.last())			 	
    
    val numbers = setOf(1, 14, 2)
    println( numbers.javaClass )
    println(numbers.maxOrNull())
}

// class java.util.HashSet
// class java.util.ArrayList
// class java.util.HashMap
// class java.util.Arrays$ArrayList
// fourteenth
// class java.util.LinkedHashSet
// 14

//_________________________________________________________

// val T
// fun T() 
// class T
// fun joinToString()

// Polymorphism
//		Compile Time Polymorphism	
// Generics/Templates
//		Generics Is A Code Which Generates Code
//		Code Generation Happens At Compile Time

fun <T> joinToString(
	collection: Collection<T>,
	separator: String,
	prefix: String,
	postfix: String
) : String {
	val result = StringBuilder( prefix )

	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

// Compiler Will Generate Following Code For The Above Generic Function
fun joinToStringInt(
	collection: Collection<Int>,
	separator: String,
	prefix: String,
	postfix: String
) : String {
	val result = StringBuilder( prefix )

	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun joinToStringString(
	collection: Collection<String>,
	separator: String,
	prefix: String,
	postfix: String
) : String {
	val result = StringBuilder( prefix )

	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun playWithJoinToString() {
	val numbers = listOf(10, 20, 30, 90, 70) // From RHS Infer ArrayList<Int>
	println( joinToString( numbers, ";", "(", ")"))
	println( joinToString( numbers, " : ", "[ ", " ]"))

	// From RHS Infer ArrayList<String>
	val names = listOf("Aice", "Ding", "Dong", "Ting", "Tong", "Gabbar")
	println( joinToString( names, ";", "(", ")"))
	println( joinToString( names, " : ", "[ ", " ]"))

}

// Function : playWithJoinToString
// (10;20;30;90;70)
// [ 10 : 20 : 30 : 90 : 70 ]

//_________________________________________________________


fun getLastChar( string: String ) : Char {
	return string.get( string.length -1 )
}

// Extension Function
//		lastChar Is Extension Function On Type String

fun String.lastChar(): Char {
	return this.get( this.length -1 )	
}

fun playWithLastChar() {
	println( getLastChar("Good Morning!") )
	println( getLastChar("BajajFinServ") )

	println( "Good Morning!".lastChar() )
	println( "BajajFinServ".lastChar() )
}


//_________________________________________________________


fun <T> Collection<T>.joinToStringExtension(
	separator: String,
	prefix: String,
	postfix: String
) : String {
	val result = StringBuilder( prefix )

	for( (index, element) in this.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun playWithJoinToStringExtension() {
	val numbers = listOf(10, 20, 30, 90, 70) // From RHS Infer ArrayList<Int>
	println( numbers.joinToStringExtension( ";", "(", ")"))
	println( numbers.joinToStringExtension( " : ", "[ ", " ]"))

	// From RHS Infer ArrayList<String>
	val names = listOf("Aice", "Ding", "Dong", "Ting", "Tong", "Gabbar")
	println( names.joinToStringExtension( ";", "(", ")"))
	println( names.joinToStringExtension( " : ", "[ ", " ]"))

}

//_________________________________________________________

fun Collection<String>.join(
	separator: String,
	prefix: String,
	postfix: String
) = joinToStringExtension( separator, prefix, postfix )

fun playWithJoinExtension() {
	// val numbers = listOf(10, 20, 30, 90, 70) // From RHS Infer ArrayList<Int>
	// println( numbers.join( ";", "(", ")"))
	// println( numbers.join( " : ", "[ ", " ]"))

	// From RHS Infer ArrayList<String>
	val names = listOf("Aice", "Ding", "Dong", "Ting", "Tong", "Gabbar")
	println( names.join( ";", "(", ")"))
	println( names.join( " : ", "[ ", " ]"))

}

//_________________________________________________________
// Extension Properties

// lastCharacter Is Extension Property On Type String
val String.lastCharacter: Char
	get() = get(length -1)

// lastCharacter Is Extension Property On Type StringBuilder
var StringBuilder.lastCharacter: Char
	get() = get( length - 1 )
	set( value: Char ) {
		this.setCharAt( length - 1, value )
	}

fun playWithJoinExtensionProperties() {
	println( "Good Morning!".lastCharacter )
	println( "BajajFinServ".lastCharacter )

	val greeting = StringBuilder("Hey#")
	println( greeting.lastCharacter )
	greeting.lastCharacter = '!'
	println( greeting.lastCharacter )
}

//_________________________________________________________

class User(val id: Int, val name: String, val address: String)

fun saveUser(user: User) {
	// Validation Of User Data
	if ( user.name.isEmpty() ) {
		throw IllegalArgumentException("User Name Empty For ${user.id}")
	}

	if ( user.address.isEmpty() ) {
		throw IllegalArgumentException("User Address Empty For ${user.id}")
	}

	// Logic To Save The User Data
	// Int Data Base
	println("Saving Data In DataBase...")
}

fun playWithUser() {
	val gabbar = User( 420, "Gabbar Singh", "Ramgarh")
	val alice = User(100, "Alice", "London")
	saveUser( gabbar )
	saveUser( alice )
}

//_________________________________________________________

// class User(val id: Int, val name: String, val address: String)

fun saveUserAgain(user: User) {
	// Local Function
	//		Function Defined Inside A Function
	fun validate( value: String, field: String) {
		if ( value.isEmpty() ) {
			throw IllegalArgumentException("User $field Empty For ${user.id}")	
		}
	}

	// Validation Of User Data
	validate( user.name, "Name" )
	validate( user.address, "Address" )

	// Logic To Save The User Data
	// Int Data Base
	println("Saving User ${user.name} In DataBase...")
}

fun playWithUserAgain() {
	val gabbar = User( 420, "Gabbar Singh", "Ramgarh")
	val alice = User(100, "Alice", "London")
	saveUserAgain( gabbar )
	saveUserAgain( alice )
}

//_________________________________________________________


fun User.save() {
	// Local Function
	//		Function Defined Inside A Function
	fun validate( value: String, field: String) {
		if ( value.isEmpty() ) {
			throw IllegalArgumentException("User $field Empty For ${this.id}")	
		}
	}

	// Validation Of User Data
	validate( this.name, "Name" )
	validate( this.address, "Address" )

	// Logic To Save The User Data
	// Int Data Base
	println("Saving User ${this.name} In DataBase...")
}

fun playWithUserOnceAgain() {
	val gabbar = User( 420, "Gabbar Singh", "Ramgarh")
	val alice = User(100, "Alice", "London")
	gabbar.save()
	alice.save()
}

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________


fun main() {
	println("\nFunction : playWithCollectionsInKotlin")
	playWithCollectionsInKotlin()

	println("\nFunction : playWithJoinToString")
	playWithJoinToString()

	println("\nFunction : playWithLastChar")
	playWithLastChar()

	println("\nFunction : playWithJoinToStringExtension")
	playWithJoinToStringExtension()

	println("\nFunction : playWithJoinExtension")
	playWithJoinExtension()

	println("\nFunction : playWithJoinExtensionProperties")
	playWithJoinExtensionProperties()

	println("\nFunction : playWithUser")
	playWithUser()

	println("\nFunction : playWithUserAgain")
	playWithUserAgain()

	println("\nFunction : playWithUserOnceAgain")
	playWithUserOnceAgain()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

