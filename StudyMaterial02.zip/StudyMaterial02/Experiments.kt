
package learnKotlin

object India {
	var name = "India"
	fun changeName( newName: String ) {
		name = newName
	} 
}

fun playWithIndia() {	
	println( India.name )
	India.changeName( "Bharat")
	println( India.name )
}

fun main() {
	playWithIndia()
}
