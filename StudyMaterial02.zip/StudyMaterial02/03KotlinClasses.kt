/*
kotlinc 03KotlinClasses.kt -include-runtime -d classes.jar
java -jar classes.jar
*/
package learnKotlin

import java.util.Comparator
import java.io.File

//_________________________________________________________

// In Kotin
// 		Classes Are Final By Default
//			Final Classes Means Can't Inherit
//		Members Are Also Final By Default
//			Final Members Means Can't Overwritten

// In Java/C++
// 		Classes Are Open By Default
//			Open Classes Means Can Inherit
//		Members Are Also Open By Default
//			Final Members Means Can Be Overwritten

// DESIGN PRINCIPLE
//		Design Towards Immutability Rather Than Mutability

// BEST DESIGN PRACTICE
//		Classes Which Are Not Meant To Be Inherited Must Be Final


open class View {
	open fun click() = println("View Clicked!")
}

// Inheriting From View
class Button: View() {
	override fun click() 	= println("Button Clicked!")
	fun magic() 	= println("Button Magic..!")
}

fun playWithInheritance() {
	val view = View()
	view.click()

	val button = Button()
	button.click()
	button.magic()
}

//_________________________________________________________

fun View.showOff() = println("View Showoff!")
fun Button.showOff() = println("Button Showoff!")

fun playWithInheritanceAndExtensions() {
	val view = View()
	view.click()
	view.showOff()

	val button = Button()
	button.click()
	button.magic()
	button.showOff()

	val viewAgain : View = Button()
	viewAgain.click()
	viewAgain.showOff() // Extension Functions CAN'T Be Overriden!
	// Seeing object w.r.t. Parent Type Perceptive
	// viewAgain.magic()   // error: unresolved reference: magic
}

//_________________________________________________________

// In Kotlin
//		intefaces Are By Default Open
//		Members Are Also By Default Open
//		Interface Members Must Be Implemented In Concrete Classes

// Abstract Interfaces
// Interfaces With Member Functions

// What To Do!
interface Clickable {
	fun click()
	// Functions With Default Implementation
	fun magic() = println("Clickable Focus..!")
}

interface Foucable {
	fun focus()
	// Functions With Default Implementation
	fun magic() = println("Foucable Focus..!")
}

// Concrete Classes
// How To Do! When To Do, Why To Do! Which Way To Do!
// Implementing Interface
class ButtonAgain: Clickable, Foucable {
	// error: 'click' hides member of supertype 'Clickable1' and needs 'override' modifier
	override fun click() = println("ButtonAgain Clicked!")
	override fun focus() = println("ButtonAgain Focused!")
	// override fun magic() = println("ButtonAgain Magic..!")
	override fun magic() {
		// error: many supertypes available, 
		// please specify the one you mean in angle brackets, e.g. 'super<Foo>'
		// super.magic()

		// Resolving Conflict
		super<Foucable>.magic()
		super<Clickable>.magic()
	}
}

fun playWithInterfaces() {
	val button = ButtonAgain()

	button.click()
	button.focus()
	button.magic()
}

//_________________________________________________________

interface Clickable1 {
    fun click()
    fun showOff() = println("I'm clickable!")
}

open class RichView {
	open fun click() = println("RichView Clicked!")
}

open class RichButton : RichView(), Clickable1 {
    override fun click() = println("RichButton Clicked!")

    fun disable() = println("RichButton Disabled!")
    open fun animate() = println("RichButton Animate!")
}

open class VeryRichButton: RichButton() {
	// Once Member Is Open: It's Always Open i.e. Overridable
	//		Don't Want To Open After Certain Stage Then Make It Final
	final override fun animate() = println("VeryRichButton Animate!")
}

class DefaultVeryRichButton: VeryRichButton() {
	// error: 'animate' in 'VeryRichButton' is final and cannot be overridden
	// override fun animate() = println("DefaultVeryRichButton Animate!")
}

fun playWithRichButtons() {
	val veryRichButton =  VeryRichButton()

	veryRichButton.click()
	veryRichButton.showOff()
	veryRichButton.disable()
	veryRichButton.animate()
}

//_________________________________________________________

interface Expr
class Num(val value: Int) : Expr
class Sum(val left: Expr, val right : Expr ) : Expr

fun evaluate( e: Expr ) : Int = when ( e ) {
	is Num 	-> e.value
	is Sum 	-> evaluate( e.left ) + evaluate( e.right )
	else  	-> throw IllegalArgumentException("Unknown Expression")
}

fun playWithEvaluate() {
	// 10 + 20
	println( evaluate( Sum( Num(10), Num(20) ) ) )
	// (10 + 20) + 100
	println( evaluate( Sum( Sum( Num(10), Num(20) ), Num(100) ) ) )
}

//_________________________________________________________

sealed class Exprn {
	class Num(val value: Int) : Exprn()
	class Sum(val left: Exprn, val right : Exprn ) : Exprn()
}

fun evaluateAgain( e: Exprn ) : Int = when ( e ) {
	is Exprn.Num 	-> e.value
	is Exprn.Sum 	-> evaluateAgain( e.left ) + evaluateAgain( e.right )
	//  warning: 'when' is exhaustive so 'else' is redundant here
	// else  	-> throw IllegalArgumentException("Unknown Expression")
}

fun playWithEvaluateAgain() {
	// 10 + 20
	println( evaluateAgain( Exprn.Sum( Exprn.Num(10), Exprn.Num(20) ) ) )
	// (10 + 20) + 100
	println( evaluateAgain( Exprn.Sum( Exprn.Sum( Exprn.Num(10), Exprn.Num(20) ), 
											Exprn.Num(100) ) ) )
}

//_________________________________________________________
// Interfaces With Properties

interface User {
	val nickName: String
}

//  error: 'nickName' hides member of supertype 'User' and needs 'override' modifier
// class PrivateUser(val nickName: String) : User
class PrivateUser( override val nickName: String ) : User

class SubscribingUser(val email: String): User {
//  error: 'nickName' hides member of supertype 'User' and needs 'override' modifier
// 	val nickName: String
	override val nickName: String
		get() = email.substringBefore('@')
}

fun playWithInteracesWithProperties() {
	val alice = SubscribingUser("alice.carol@gmail.com")
	println( alice.nickName )

	val gabbar = PrivateUser("Gabbar Singh")
	println( gabbar.nickName )
}

//_________________________________________________________

interface ClickableInterface {
	fun magic() = println("Clickable Focus..!")
}

class ClickableClass {
	fun magic() = println("Clickable Focus..!")
}

//_________________________________________________________

interface UserAgain {
	val email: String
	val nickName: String
		get() = email.substringBefore('@')
}

interface Human {
	// var somethingAgain = "Ding Dong"
	var somethingAgain: String
	var name: String
		get() = "Hello!"
		set( value ) {
			val something = value
			println("Human Interface name Have Something : $something")
			// field = value
		}
}

//_________________________________________________________

class UserOnceAgain( val name: String ) {
	var address: String = "Unspeficied"
		get() {
			println("Getter Getting Called : $field")
			return field
		}
		set( value: String ) {
			// field Is Backing Field/Member Variable
			println("Setter Getting Called : $field")
			field = value
			println("Setter Getting Called : $field")
		}
}

fun playWithUserOnceAgain() {
	val gabbar = UserOnceAgain("Gabbar Singh")
	println( gabbar.name )
	println( gabbar.address )

	gabbar.address = "Ramgarh!"
	println( gabbar.name )
	println( gabbar.address )	
}

//_________________________________________________________


class LengthCounter {
	var counter: Int = 0
		private set

	fun addWord( word: String ) {
		counter += word.length
	}
}

fun playWithCounter() {
	val countCharacter = LengthCounter()

	countCharacter.addWord("Hello,")
	println( countCharacter.counter )

	countCharacter.addWord("Gabbar")
	println( countCharacter.counter )

	countCharacter.addWord("!")
	println( countCharacter.counter )
}

//_________________________________________________________

// class India {
// 	fun name() = "Bharat"
// }

// Object Class
//		It's Singleton Classes
//			Classes Having Only One Instance
//		Instance Name Is Same As Class Name

object India {
	var name = "India"
	fun changeName( newName: String ) {
		name = newName
	} 
}

fun playWithIndia() {	
	println( India.name )
	India.changeName( "Bharat")
	println( India.name )
}

//_________________________________________________________

class Client1(val name: String, val postalCode: Int) {
	override fun toString() : String {
		return "Client1(name=$name, postalCode=$postalCode"
	}

	override fun equals( other : Any? ) : Boolean {
		if ( other == null || other !is Client1 ) return false
		return name == other.name && postalCode == other.postalCode
	}
}

fun playWithClient1() {
	val gabbar = Client1("Gabbar Singh", 420420)
	val alice = Client1("Alice Carol", 909090)
	val aliceAgain = Client1("Alice Carol", 909090)

	// println( gabbar.name )
	// println( gabbar.postalCode )
	// println( alice.name )
	// println( alice.postalCode )

	println( gabbar ) // println( gabbar.toString() )
	println( alice )  // println( alice.toString() )

	println( alice == aliceAgain )  // alice.equals( aliceAgain )
	println( alice == gabbar ) 		// alice.equals( gabbar )
	println( aliceAgain == gabbar ) // aliceAgain.equals( gabbar )

	println( alice.equals( aliceAgain ) )
	println( alice.equals( gabbar ) )
	println( aliceAgain.equals( gabbar ) )
}

// Function : playWithClient1
// learnKotlin.Client1@723279cf
// learnKotlin.Client1@10f87f48

//_________________________________________________________
// Data Classes

//	Compiler Will Generate Following Methods
//		1. toString() Method
//				Will Give String Representation Of All The Member Properties
//		2. equals Method
//				Will Compare All The Properties
//		3. hasCode Method
//				Will Generate HashCode On All The Immutable Properties
data class Client2(val name: String, val postalCode: Int) 
// Following Commented Methods Will Be Generated By Compiler For Data Classes
// {
// 	override fun toString() : String {
// 		return "Client1(name=$name, postalCode=$postalCode"
// 	}

// 	override fun equals( other : Any? ) : Boolean {
// 		if ( other == null || other !is Client1 ) return false
// 		return name == other.name && postalCode == other.postalCode
// 	}
// }

fun playWithClient2() {
	val gabbar = Client2("Gabbar Singh", 420420)
	val alice = Client2("Alice Carol", 909090)
	val aliceAgain = Client2("Alice Carol", 909090)

	// println( gabbar.name )
	// println( gabbar.postalCode )
	// println( alice.name )
	// println( alice.postalCode )

	println( gabbar ) // println( gabbar.toString() )
	println( alice )  // println( alice.toString() )

	println( alice == aliceAgain )  // alice.equals( aliceAgain )
	println( alice == gabbar ) 		// alice.equals( gabbar )
	println( aliceAgain == gabbar ) // aliceAgain.equals( gabbar )

	println( alice.equals( aliceAgain ) )
	println( alice.equals( gabbar ) )
	println( aliceAgain.equals( gabbar ) )
}

//_________________________________________________________

// import java.util.Comparator
// import java.io.File

object CaseInsensitiveFileComparator : Comparator<File> {
    override fun compare(file1: File, file2: File): Int {
        return file1.path.compareTo(file2.path, ignoreCase = true)
    }
}

fun objectDeclarations() {
    println( CaseInsensitiveFileComparator.compare(
        File("/User"), File("/user")))

    val files = listOf(File("/Z"), File("/a"))
    
    println(files.sortedWith(CaseInsensitiveFileComparator))
}

//_________________________________________________________

data class Person(val firstName: String, val lastName: String) {
    object FirstNameComparator : Comparator<Person> {
        override fun compare(person1: Person, person2: Person): Int =
            person1.firstName.compareTo(person2.firstName)
    }

    object LastNameComparator : Comparator<Person> {
        override fun compare(person1: Person, person2: Person): Int =
            person1.lastName.compareTo(person2.lastName)
    }
}

fun playWithComparator() {
    val persons = listOf( 
    	Person("Gabbar", "Singh"), 
    	Person("Michael", "Holding"), 
    	Person("Kapil", "Dev"), 
    	Person("Alice", "Carol") 
    )

    println( persons.sortedWith(Person.FirstNameComparator))
    println( persons.sortedWith(Person.LastNameComparator))
}

//_________________________________________________________

// Instance/Object Member
//		Members Which Are Binded With Instance/Object

// In Kotlin and Java
//		All Members Are By Default Instance/Object Member

// Class/Type Member
//		Members Which Are Binded With Type/Class
// In Java
//		Using static Methods or Members
// In Kotlin
//		Using Companion Object

class Magic {
	companion object {
		// Class/Type Member
		// 
		var something: Int = 100
		
		fun doMagic() = println("Magic Happening!")
	}

	// Object/Instance Member
	fun doSomething() = println("Something Is Done!") 
}

fun playWithMagic() {
	val magic = Magic()
	magic.doSomething()

	// Magic.doSomething()
	Magic.doMagic()
}

//_________________________________________________________


fun getFacebookName(accountID: Int) = "FB:$accountID"

class UserOnceMore private constructor(val name: String) {

	// Design Pattern : Factory Methods
	// 		Implemented Using Companion Object
	companion object {
		// Factory Method
		fun newSubscribingUser( email: String ) : UserOnceMore {
			return UserOnceMore( email.substringBefore('@') )
		}

		// Factory Method
		fun newFacebookUser( accountID: Int ) : UserOnceMore {
			return UserOnceMore( getFacebookName( accountID) )
		}
	}

	override fun toString() = "PersonAgain(name=$name)"
}


fun playWithFactoryMethods() {
	val subscribingUser = UserOnceMore.newSubscribingUser( "gabbar@india.com" )
	val facebookUser = UserOnceMore.newFacebookUser( 999 )

	println( subscribingUser )
	println( facebookUser )

	println( subscribingUser.hashCode() )
	println( facebookUser.hashCode() )
}


//_________________________________________________________

open class Car(val model: String, val engine: String) {
	override fun toString() = "Car(model=$model, engine=$engine)"
}

class PetrolCar(model: String, engine: String) : Car(model, engine) 
class DieselCar(model: String, engine: String) : Car(model, engine)
class ElectricCar(model: String, engine: String) : Car(model, engine)
class UnknownCar(model: String, engine: String) : Car(model, engine)


class CarFactory private constructor(val location: String) {

	companion object {
		// Factory Method
		fun createCar(model: String, fuelType: String) : Car {
			return when ( fuelType ) {
				"Petrol" 	->  PetrolCar(model, "PetrolEngine")
				"Diesel" 	->  PetrolCar(model, "DieselEngine")
				"Electric" 	->  PetrolCar(model, "ElectricEngine")
				else 		->  UnknownCar(model, "Unknown")
			}
		}
	}
}

fun playWithCarFactory() {
	val nano = CarFactory.createCar("Nano", "Petrol")
	val mahindra = CarFactory.createCar("Thar", "Diesel")
	val tesla = CarFactory.createCar("Tesla", "Electric")

	println( nano )
	println( mahindra )
	println( tesla )
}


//_________________________________________________________

class CarFactoryAgain {
	// Class Defined Inside Class
	open class Car(val model: String, val engine: String) {
		override fun toString() = "Car(model=$model, engine=$engine)"
	}

	class PetrolCar(model: String, engine: String) : Car(model, engine) 
	class DieselCar(model: String, engine: String) : Car(model, engine)
	class ElectricCar(model: String, engine: String) : Car(model, engine)
	class UnknownCar(model: String, engine: String) : Car(model, engine)

	companion object {
		// Factory Method
		fun createCar(model: String, fuelType: String) : Car {
			return when ( fuelType ) {
				"Petrol" 	->  PetrolCar(model, "PetrolEngine")
				"Diesel" 	->  DieselCar(model, "DieselEngine")
				"Electric" 	->  ElectricCar(model, "ElectricEngine")
				else 		->  UnknownCar(model, "Unknown")
			}
		}
	}
}

fun playWithCarFactoryAgain() {
	val nano = CarFactoryAgain.createCar("Nano", "Petrol")
	val mahindra = CarFactoryAgain.createCar("Thar", "Diesel")
	val tesla = CarFactoryAgain.createCar("Tesla", "Electric")

	println( nano )
	println( mahindra )
	println( tesla )
}


//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________


fun main() {
	println("\nFunction : playWithInheritance")
	playWithInheritance()

	println("\nFunction : playWithInheritanceAndExtensions")
	playWithInheritanceAndExtensions()

	println("\nFunction : playWithInterfaces")
	playWithInterfaces()

	println("\nFunction : playWithEvaluateAgain")
	playWithEvaluateAgain()

	println("\nFunction : playWithInteracesWithProperties")
	playWithInteracesWithProperties()

	println("\nFunction : playWithUserOnceAgain")
	playWithUserOnceAgain()

	println("\nFunction : playWithIndia")
	playWithIndia()

	println("\nFunction : playWithClient1")
	playWithClient1()

	println("\nFunction : playWithClient2")
	playWithClient2()

	println("\nFunction : playWithComparator")
	playWithComparator()

	println("\nFunction : playWithMagic")
	playWithMagic()

	println("\nFunction : playWithFactoryMethods")
	playWithFactoryMethods()

	println("\nFunction : playWithCarFactory")
	playWithCarFactory()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

