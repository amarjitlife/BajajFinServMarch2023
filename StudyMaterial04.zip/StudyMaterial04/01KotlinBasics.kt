/*
kotlinc KotlinBasics.kt -include-runtime -d basics.jar
java -jar basics.jar
*/
package learnKotlin

import java.util.Random
import java.util.TreeMap

//____________________________________________________
fun helloWorld() {
	println("Hello World!")
}

//____________________________________________________

fun max(a: Int, b: Int) : Int {
	return if ( a > b ) a else b
}

// Function Is First Class Citizen
//		It Can Be Assigned Value
fun maximum(a: Int, b: Int) = if ( a > b ) a else b

fun maxDiscusion(a: Int, b: Int) : Int {
	return if ( a > b ) {
		a //  warning: the expression is unused
		a + 10
	}
	else {
		b //  warning: the expression is unused
		b + 100
	}
}

fun playWithMax() {
	println( max( 100, 200 ))
	println( max( 1000, -200 ))

	println( maximum( 100, 200 ))
	println( maximum( 1000, -200 ))
}

//_________________________________________________________

// DESIGN PRINCIPLE
//		Design Towards Immutability Rather Than Mutability

// val Means Immutable
// var Means Mutable

// Defining Type Person
//		Have Two Properties
class Person(val name: String, var isMarried: Boolean)

fun playWithPerson() {
	val alice = Person("Alice Carol", true)
	val gabbar = Person("Gabbar Singh", false)

	println(alice.name) 		// alice.getName()
	println(alice.isMarried) 	//alice.GetIsMarried()

// 	error: val cannot be reassigned
	// alice.name = "Alice Malinda"
	alice.isMarried = true    // alice.setIsMarried( true )

	println(alice.name) 		// alice.getName()
	println(alice.isMarried) 	//alice.GetIsMarried()

	println(gabbar.name)
	println(gabbar.isMarried)
}

//_________________________________________________________

class Rectangle(val height: Int, val width: Int) {
	val isSquare: Boolean
		get() {
			return height == width
		}
}

fun playWithRectangle() {
	val rectangle1 = Rectangle(100, 200)
	println( rectangle1.isSquare ) // rectangle1.getIsSquare()

	val rectangle2 = Rectangle(200, 200)
	println( rectangle2.isSquare )	
}

//_________________________________________________________

// Kotlin Is Compatible With Java 1.6+ Onwards
// Using Java Classes Inside Kotlin Code

// import java.util.Random

fun playWithRandom() {
	val random = Random()
	val rectangle = Rectangle( random.nextInt(), random.nextInt() )
	println( rectangle.isSquare )
}

//_________________________________________________________


enum class Colour {
	RED, GREEN, BLUE, YELLOW
}

// DESIGN PRINCIPLE
//		Design Towards Deterministic System Rather Than Non Deterministic System

// error: type mismatch: inferred type is String but Unit was expected
// fun getColourString( Colour: Colour ) {
fun getColourStringOld( colour: Colour ) : String {	
	// when Is Expression
	return when( colour ) {
		Colour.RED 	-> "Red Colour"
		Colour.GREEN -> "Green Colour"
		Colour.BLUE  -> "Blue Colour"
		Colour.YELLOW  -> "Yellow Colour"
		// error: 'when' expression must be exhaustive, add necessary 'YELLOW' branch or 'else' branch instead
		// else 		-> "Unknown Colour"
	}
} 

// Write Code Like Poetry!
// when Is Type Safe Expression
fun getColourString( colour: Colour ) = when( colour ) {
	Colour.RED 	-> "Red Colour"
	Colour.GREEN -> "Green Colour"
	Colour.BLUE  -> "Blue Colour"
	Colour.YELLOW  -> "Yellow Colour"
	// else 		-> "Unknown Colour"
}

fun playWithEnums() {
	println( getColourStringOld( Colour.RED ) )
	println( getColourStringOld( Colour.GREEN ) )
	println( getColourStringOld( Colour.BLUE ) )

	println( getColourString( Colour.RED ) )
	println( getColourString( Colour.GREEN ) )
	println( getColourString( Colour.BLUE ) )
}

//_________________________________________________________
// DESIGN PRINCIPLE
//		Club Constant States Together Which Have Relationhip

// DESIGN PRINCIPLE
//		Flat Is Better Than Nested

// Type Color
//		Range =  ( RED, GREEN, BLUE, ORANGE, YELLOW, UNKNOWN )
enum class Color(val r: Int, val g: Int, val b: Int) {
	RED(255, 0, 0), GREEN(0, 255, 0), BLUE(0, 0, 255), 
	ORANGE(200, 200, 200), YELLOW( 200, 100, 100), UNKNOWN(0, 0, 0);

	fun rgb() = ( r * 256 + g ) * 256 + b
}

fun playWithColor() {
	println( Color.RED )
	println( Color.RED.r )
	println( Color.RED.g )
	println( Color.RED.b )

	println( Color.RED.rgb() )
	println( Color.GREEN )
	println( Color.BLUE )
	println( Color.GREEN.rgb() )
	println( Color.BLUE.rgb() )
}

//_________________________________________________________
// DESIGN PRINCIPLE
//		Exceptions are Not That Exceptional Such That It Should Break Your Design
//		Always Cover Exaustive Cases Rather Than else Branch
//		Use else Branch Only For Exponential Cases
//		
fun mixColors(c1: Color, c2: Color) = when ( setOf(c1, c2) ) {
    setOf(Color.RED, Color.YELLOW) -> Color.ORANGE
    setOf(Color.YELLOW, Color.BLUE) -> Color.GREEN
    // setOf(Color.BLUE, Color.VIOLET) -> Color.INDIGO
    else -> throw Exception("Dirty color")
}

fun mixColorsAgain(c1: Color, c2: Color) : Color {
	return when ( setOf(c1, c2) ) {
	    setOf(Color.RED, Color.YELLOW) 	-> Color.ORANGE
	    setOf(Color.YELLOW, Color.BLUE) -> Color.GREEN
	    // setOf(Color.BLUE, Color.VIOLET) -> Color.INDIGO
		// KotlinBasics.kt:185:9: error: type mismatch: inferred type is String but Unit was expected
	    // else -> "Unknown Color"
	    else -> throw Exception("Unknown Color")
	}
}

fun mixColorsOnceAgain(c1: Color, c2: Color) : Color {
	return when ( setOf(c1, c2) ) {
	    setOf(Color.RED, Color.YELLOW) 	-> Color.ORANGE
	    setOf(Color.YELLOW, Color.BLUE) -> Color.GREEN
	    // setOf(Color.BLUE, Color.VIOLET) -> Color.INDIGO
		// KotlinBasics.kt:185:9: error: type mismatch: inferred type is String but Unit was expected
	    // else -> "Unknown Color"
	    else -> Color.UNKNOWN
	}
}

// KotlinBasics.kt:185:9: error: type mismatch: inferred type is Color but Unit was expected
// 	return when ( setOf(c1, c2) ) {
//         ^
// 	return when ( setOf(c1, c2) ) {

fun playWithMixColor() {
	println( mixColors( Color.RED, Color.YELLOW) )
	println( mixColors( Color.BLUE, Color.YELLOW) )
	// Exception in thread "main" java.lang.Exception: Dirty color
	// println( mixColors( Color.GREEN, Color.BLUE ) )

	println( mixColorsAgain( Color.RED, Color.YELLOW) )
	println( mixColorsAgain( Color.BLUE, Color.YELLOW) )

	println( mixColorsOnceAgain( Color.RED, Color.YELLOW) )
	println( mixColorsOnceAgain( Color.BLUE, Color.YELLOW) )
	println( mixColorsOnceAgain( Color.GREEN, Color.BLUE ) )
}

//_________________________________________________________

fun playWithTypeInferencing() {
	val something = 100
	println(something)

	val somethingAgain: Int = 900
	println(somethingAgain)

	val some = 90.90
	println( some )

	val someAgain: Double = 90.90
	println( someAgain )

	val someAgain1: Float = 90.90F
	println( someAgain1 )

	val greeting = "Good Evening!"
	val greetingAgain: String = "Good Evening!"
	println(greeting)
	println(greetingAgain)

	// error: variable 'someMore' must be initialized
	// val someMore
	// print(someMore)
	val someMore1 : Int

}

//_________________________________________________________

//_________________________________________________________

fun getColourStringMore( colour: Colour ) : String {	
	// when Is Expression
	return when( colour ) {
		Colour.RED 		-> "Red Colour"
		Colour.GREEN 	-> "Green Colour"
		Colour.BLUE  	-> "Blue Colour"
		//error: the integer literal does not conform to the expected type String
		// Colour.YELLOW  	-> 100
		Colour.YELLOW  	-> "Yellow Color"
	}
} 

fun getColourStringOnceMore( colour: Colour ) : String = when( colour ) {
	Colour.RED 		-> "Red Colour"
	Colour.GREEN 	-> "Green Colour"
	Colour.BLUE  	-> "Blue Colour"
	//error: the integer literal does not conform to the expected type String
	// Colour.YELLOW  	-> 100
	Colour.YELLOW  	-> "Yellow Color"
}
 
//_________________________________________________________

interface Expr
class Num(val value: Int) : Expr
class Sum(val left: Expr, val right : Expr ) : Expr

fun eval( e: Expr ) : Int {

	if ( e is Num ) { // Smart Castin
		return e.value
	}

	if ( e is Sum ) {
		return eval( e.left ) + eval( e.right )
	}

	throw IllegalArgumentException("Unknown Expression")
}

fun playWithEval() {
	// 10 + 20
	println( eval( Sum( Num(10), Num(20) ) ) )
	// (10 + 20) + 100
	println( eval( Sum( Sum( Num(10), Num(20) ), Num(100) ) ) )

}

//_________________________________________________________

// interface Expr
// class Num(val value: Int) : Expr
// class Sum(val left: Expr, val right : Expr ) : Expr

// error: type checking has run into a recursive problem.
//		 Easiest workaround: specify types of your declarations explicitly
// fun evalIf( e: Expr ) = if ( e is Num ) { 
fun evalIf( e: Expr ) : Int = if ( e is Num ) { 
		e.value
		// "Ding Dong"
	} else if ( e is Sum ) {
		evalIf( e.left ) + evalIf( e.right )
	} else {
		throw IllegalArgumentException("Unknown Expression")
}

fun playWithEvalIf() {
	// 10 + 20
	println( evalIf( Sum( Num(10), Num(20) ) ) )
	// (10 + 20) + 100
	println( evalIf( Sum( Sum( Num(10), Num(20) ), Num(100) ) ) )
}

//_________________________________________________________

// Types Are Theorem!
// Expr Type
//		Operation = Phi Set
//		Range 	  = Phi Set
// interface Expr
// class Num(val value: Int) : Expr
// class Sum(val left: Expr, val right : Expr ) : Expr

// Program Is Proof!
fun evaluate( e: Expr ) : Int = when ( e ) {
	is Num 	-> e.value
	is Sum 	-> evaluate( e.left ) + evaluate( e.right )
	else  	-> throw IllegalArgumentException("Unknown Expression")
}

fun playWithEvaluate() {
	// 10 + 20
	println( evaluate( Sum( Num(10), Num(20) ) ) )
	// (10 + 20) + 100
	println( evaluate( Sum( Sum( Num(10), Num(20) ), Num(100) ) ) )
}

//_________________________________________________________

fun fizzBuzz(i: Int) = when {
    i % 15 == 0 -> "FizzBuzz "  // Pattern Matching
    i % 3 == 0 -> "Fizz "
    i % 5 == 0 -> "Buzz "
    else -> "$i "
}

//_________________________________________________________

fun fizzyBuzzyThings() {
    for (i in 1..100) { // [1, 100]
        print(fizzBuzz(i))
    }
}

fun rangesProgressions() {
    for (i in 100 downTo 1 step 2) {
        print(fizzBuzz(i))
    }
}       

//_________________________________________________________

// import java.util.TreeMap

fun iteratingOverMaps() {
	val binaryRepresentation = TreeMap<Char, String>()

	for ( character in 'A'..'F' ) {
		val binary = Integer.toBinaryString( character.code )
		binaryRepresentation[ character ] = binary
	}

	for ( ( character, binary ) in binaryRepresentation ) {
		println("$character = $binary")
	}
}

//_________________________________________________________

fun isLetter( character : Char ) = character in 'a'..'z' || character in 'A'..'Z'
fun isNotDigit( character : Char ) = c !in '0'..'9'

fun recognize(c: Char) = when (c) {
    in '0'..'9' 			 -> "It's a digit!"
    in 'a'..'z', in 'A'..'Z' -> "It's a letter!"
    else 					 -> "I don't know..."
}


//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________


fun main() {
	println("\nFunction : helloWorld")
	helloWorld();

	println("\nFunction : playWithMax")
	playWithMax()

	println("\nFunction : playWithPerson")
	playWithPerson()

	println("\nFunction : playWithRectangle")
	playWithRectangle()

	println("\nFunction : playWithRandom")
	playWithRandom()

	println("\nFunction : playWithEnums")
	playWithEnums()

	println("\nFunction : playWithColor")
	playWithColor()

	println("\nFunction : playWithMixColor")
	playWithMixColor()

	println("\nFunction : playWithTypeInferencing")
	playWithTypeInferencing()

	println("\nFunction : playWithEval")
	playWithEval()

	println("\nFunction : playWithEvalIf")
	playWithEvalIf()

	println("\nFunction : playWithEvaluate")
	playWithEvaluate()

	println("\nFunction : iteratingOverMaps")
	iteratingOverMaps()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

