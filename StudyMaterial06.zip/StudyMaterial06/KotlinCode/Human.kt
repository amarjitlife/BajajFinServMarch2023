/*
kotlinc Human.kt -include-runtime -d human.jar
java -jar human.jar
*/
package learnKotlin

//______________________________________________________________

interface Superpower {
	fun fly()
	fun saveWorld()
}

class Spiderman : Superpower {
	override fun fly() = println("Fly Like Spiderman!")
	override fun saveWorld() = println("Save World Like Spiderman!")
}

class Superman: Superpower {
	override fun fly() = println("Fly Like Superman!")
	override fun saveWorld() = println("Save World Like Superman!")
}

class Heman : Superpower {
	override fun fly() = println("Fly Like Heman!")
	override fun saveWorld() = println("Save World Like Heman!")
}

class HanumanJi : Superpower {
	override fun fly() = println("Fly Like HanumanJi!")
	override fun saveWorld() = println("Save World Like HanumanJi!")
}

open class Wonderwoman {
	open fun fly() = println("Fly Like Wonderwoman!")
	open fun saveWorld() = println("Save World Like Wonderwoman!")
}

//______________________________________________________________

// Using Inheritance
// class Human : Spiderman() {
// class Human : Superman() {
// class Human : Heman() {
class Human : Wonderwoman() {
	override fun fly() 		= super.fly() 		//= println("Fly Like Human!")
	override fun saveWorld() = super.saveWorld() //= println("Save World Like Human!")
}


//______________________________________________________________

// Composition Is Equivalent To Inheritance
//		Whatever You Can Do With Inheritance You Can Do With Composition
//Using Composition
class HumanAgain {
	// But Still Changing With Newer Power
	// var power: Superman = Superman()
	var power: Spiderman = Spiderman()	
	fun fly() 		 = power.fly() 		//= println("Fly Like Human!")
	fun saveWorld() = power.saveWorld() //= println("Save World Like Human!")
}

fun playWithHuman() {
	val human = Human()

	human.fly()
	human.saveWorld()

	val humanAgain = HumanAgain()
	humanAgain.fly()
	humanAgain.saveWorld()
}

//______________________________________________________________

// DESIGN PRINCIPLE
//		Design Towards Abstract Type Rather Than Concrete Type

//		Corollary:
//			Design Towards Interfaces Rather Than Concrete Classes

// Polymoprhic
class HumanBetter {
	// Delegate
	var power: Superpower?	= null
	fun fly() 		 = power?.fly() 		//= println("Fly Like Human!")
	fun saveWorld()  = power?.saveWorld() //= println("Save World Like Human!")
}


fun playWithBetterHuman() {
	val betterHuman = HumanBetter()
	betterHuman.fly()
	betterHuman.saveWorld()

	betterHuman.power = Spiderman()
	betterHuman.fly()
	betterHuman.saveWorld()

	betterHuman.power = Superman()
	betterHuman.fly()
	betterHuman.saveWorld()

	betterHuman.power = Heman()
	betterHuman.fly()
	betterHuman.saveWorld()

	betterHuman.power = HanumanJi()
	betterHuman.fly()
	betterHuman.saveWorld()
}

fun saveWorld(val avengers: [Superpower] ) {
	for ( avenger in avengers ) {
		avenger.fly()
		avenger.saveWorld()
	}
}

fun activateAvengers() {
	val avengers: [Superpower] = [ Spiderman(), Superpower(), Heman(), Wonderwoman() ]

	saveWorld( avengers )
}

//______________________________________________________________

class HumanOnceAgain( power: Superpower ) : Superpower by power 
// {
// 	// Delegate
// 	var power: Superpower	= power()
// 	fun fly() 		 = power.fly() 		//= println("Fly Like Human!")
// 	fun saveWorld()  = power.saveWorld() //= println("Save World Like Human!")
// }

//______________________________________________________________


fun main() {
	playWithHuman()
	playWithBetterHuman()
	activateAvengers()

}

