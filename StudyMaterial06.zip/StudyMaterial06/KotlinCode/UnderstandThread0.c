#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

void sayHello() {
	printf("	Say Hello...");
}

void sayMorningAgain() {
	printf("	Say Morning Again...");
}

void sayMorning() {
	printf("	Say Morning...");
	sayMorningAgain();
}

void * greetingHello() {
	for ( int i = 0 ; i < 20; i++ ) {
		printf("Hello!!!\n");
		sayHello();
	}
	sleep(2);
}

void * greetingMorning() {
	for ( int i = 0 ; i < 20; i++ ) {
		printf("Good Morning!!!\n");
		sayMorning();
	}
	sleep(3);
}

void mainMagic() {
	printf("	Main Magic...");

}

int main() {
	pthread_t Thread1, Thread2;
	int result1, result2;

	result1 = pthread_create( &Thread1, NULL, *greetingHello, NULL );
	result2 = pthread_create( &Thread2, NULL, *greetingMorning, NULL );

	printf("Thread1 Result: %d\n", result1);
	printf("Thread2 Result: %d\n", result2);

	for ( int i = 0 ; i < 20; i++ ) {
		printf("Main Thread Morning!!!\n");
		mainMagic();
	}

	sleep(2);
	return 0;
}


// khoj@ubuntu2204:/media/WorkArea/Trainings.Running/BajajFinServBatch2/Progress$ ./understandingThread 
// Hello!!!
// 	Say Hello...Hello!!!
// 	Say Hello...Hello!!!
// 	Say Hello...Hello!!!
// 	Say Hello...Hello!!!
// 	Say Hello...Hello!!!
// 	Say Hello...Hello!!!
// 	Say Hello...Hello!!!
// 	Say Hello...Hello!!!
// 	Say Hello...Hello!!!
// 	Say Hello...Hello!!!
// 	Say Hello...Hello!!!
// 	Say Hello...Hello!!!
// 	Say Hello...Hello!!!
// 	Say Hello...Hello!!!
// 	Say Hello...Hello!!!
// 	Say Hello...Hello!!!
// 	Say Hello...Hello!!!
// 	Say Hello...Hello!!!
// 	Say Hello...Hello!!!
// 	Say Hello...Thread1 Result: 0
// Thread2 Result: 0
// Main Thread Morning!!!
// 	Main Magic...Main Thread Morning!!!
// 	Main Magic...Main Thread Morning!!!
// 	Main Magic...Main Thread Morning!!!
// 	Main Magic...Main Thread Morning!!!
// 	Main Magic...Main Thread Morning!!!
// 	Main Magic...Main Thread Morning!!!
// 	Main Magic...Main Thread Morning!!!
// 	Main Magic...Main Thread Morning!!!
// 	Main Magic...Main Thread Morning!!!
// 	Main Magic...Main Thread Morning!!!
// 	Main Magic...Main Thread Morning!!!
// 	Main Magic...Main Thread Morning!!!
// 	Main Magic...Main Thread Morning!!!
// 	Main Magic...Main Thread Morning!!!
// 	Main Magic...Main Thread Morning!!!
// 	Main Magic...Main Thread Morning!!!
// Good Morning!!!
// 	Say Morning...	Say Morning Again...Good Morning!!!
// 	Say Morning...	Say Morning Again...Good Morning!!!
// 	Say Morning...	Say Morning Again...Good Morning!!!
// 	Say Morning...	Say Morning Again...Good Morning!!!
// 	Say Morning...	Say Morning Again...Good Morning!!!
// 	Say Morning...	Say Morning Again...Good Morning!!!
// 	Main Magic...	Say Morning...Main Thread Morning!!!
// 	Main Magic...Main Thread Morning!!!
// 	Main Magic...Main Thread Morning!!!
// 	Main Magic...	Say Morning Again...Good Morning!!!
// 	Say Morning...	Say Morning Again...Good Morning!!!
// 	Say Morning...	Say Morning Again...Good Morning!!!
// 	Say Morning...	Say Morning Again...Good Morning!!!
// 	Say Morning...	Say Morning Again...Good Morning!!!
// 	Say Morning...	Say Morning Again...Good Morning!!!
// 	Say Morning...	Say Morning Again...Good Morning!!!
// 	Say Morning...	Say Morning Again...Good Morning!!!
// 	Say Morning...	Say Morning Again...Good Morning!!!
// 	Say Morning...	Say Morning Again...Good Morning!!!
// 	Say Morning...	Say Morning Again...Good Morning!!!
// 	Say Morning...	Say Morning Again...Good Morning!!!
// 	Say Morning...	Say Morning Again...Good Morning!!!
	// Say Morning...	Say Morning Again...