#include <stdio.h> 
#include <stdlib.h>
#include <unistd.h> 
#include <string.h>

//fork() Creates Child Process
// To create child process we use fork(). fork() returns : 
// 	< 0  Fail To Create New Child Process
// 	= 0  New Child Process Creation Successful
//  > 0 i.e process ID of the child process to the parent process. 
//		when >0 parent process will execute.

// DESCRIPTION
//    fork()  creates  a  new  process by duplicating the calling process.  
//	  The new process is referred to as the child process.  
//	  The calling process is referred to as the parent process.

//    The child process and the parent process run in separate memory spaces.
//	  At  the  time  of fork()  both  memory  spaces have the same content. 
//	  Memory writes, file mappings (mmap(2)), and unmappings (munmap(2)) 
//	  performed by one of the processes do not affect the other.

// RETURN VALUE
  //      	On success, the PID of the child process 
  //      		is returned in the parent, and 
		// 	0 is returned in the child.  
		// On failure, 
		// 	-1 is returned in the parent, 
		// 	no child process is created, and errno  is
  //      			set appropriately.

static int someData = 111;
int main() { 
	int someDataAgain = 222;
	char somethingAgain[20] = "";

	int something = fork();

	switch( something ) {
	case -1:
		printf("\nForking Failed!");
		exit( EXIT_FAILURE );
	case 0:
		someData = someData * 3;
		someDataAgain = someDataAgain * 3;
	default:
		sleep( 3 );
		break;
	}

	if ( something == 0 ) strcpy( somethingAgain, "Ding Dong" );
	else strcpy( somethingAgain, "Ting Tong" );

	printf("\n : %s", somethingAgain);
	printf("\n someData: %d someDataAgain: %d", someData, someDataAgain);
	char ch = getchar();
	return 0;
}
// : Ting Tong
// someData: 111 someDataAgain: 222
// : Ding Dong
// someData: 333 someDataAgain: 666