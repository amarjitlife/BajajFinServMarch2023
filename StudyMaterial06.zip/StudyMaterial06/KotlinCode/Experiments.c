#include <stdio.h>
#include <limits.h>

// DESIGN 1 : BAD DESIGN
int unsafeSum( int x, int y ) {
	return x + y;
}


// DESIGN 2 : BAD DESIGN

// // Always True
// MIN_INT <= x, y <= MAX_INT
// // Always False
// x >= INT_MAX OR x <= MIN_INT 

// // Always True
// MIN_INT <= result <= MAX_INT
// // Always False
// result >= INT_MAX OR result <= MIN_INT 

// // Works But Harware Dependent Code
// x >0 && y > 0 && result < 0 || x < 0 && y < 0 && result > 0


// VALID SUM
// #include <limits.h>
//___________________________________________________
  
signed int sum(signed int a, signed int b) {
	  signed int result = 0;
	  if (((b > 0) && (a > (INT_MAX - b))) ||
	      ((b < 0) && (a < (INT_MIN - b)))) {
	    /* Handle error */
	  } else {
	    	result = a + b;
	  }
	    return result;
	  /* ... */
}

void playWithSum() {
	int a, b;
	int result = 0;

	a = 2147483647;
	b = 1;
	result = sum(a, b);
	printf("\nResult : %d", result);

	a = -2147483648;
	b = -2;
	result = sum(a, b);
	printf("\nResult : %d", result);
}

//___________________________________________________
int main() {
	playWithSum();
}

// Result : -2147483648
// Result : 2147483646