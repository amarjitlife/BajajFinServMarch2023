package com.example.quizapp

import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.View.OnClickListener
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
//    private late init var trueButton: Button
//    private late init var falseButton: Button
    private val loggingTAG = "MainActivity"

//    class FalseButtonClickHandler : OnClickListener {
//        override fun onClick(v: View?) {
//            Log.d(loggingTAG, "False Button onClicked Called")
//            Toast.makeText(null, "Correct Choice!",
//                Toast.LENGTH_LONG).show()
//        }
//    }

//    @SuppressLint("SuspiciousIndentation")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val loggingTAG = "$loggingTAG: onCreate : "
//        setContentView(R.layout.activity_main)
            setContentView(R.layout.quiz_layout)

//            trueButton = findViewById<Button>(R.id.trueButton)
//            falseButton = findViewById<Button>(R.id.falseButton)

        val trueButton = findViewById<Button>(R.id.trueButton)
        val falseButton = findViewById<Button>(R.id.falseButton)

// OnClickListener Is A SAM Interface
        // Single Abstract Method Interface

// Design 01 : Implementing Explicit Classes Using Interface OnClickListener
//        class TrueButtonClickHandler : OnClickListener {
//            override fun onClick(v: View?) {
//                Log.d(loggingTAG, "True Button onClicked Called")
//            }
//        }
//        trueButton.setOnClickListener( new TrueButtonClickHandler() )

// Design 02: Using Anonymous Class Implementing Interface OnClickListener
// In JAVA : Using Anonymous Classes
//        trueButton.setOnClickListener( new OnClickListener {
//            void onClick(v: View?) {
//                Log.d(loggingTAG, "True Button onClicked Called")
//            }
//        )

// In KOTLIN : Using Object Classes
//        trueButton.setOnClickListener( object : OnClickListener {
//            override fun onClick(v: View?) {
//                Log.d(loggingTAG, "True Button onClicked Called")
//            }
//        )

//
// Design 03: Using Lambda Expression At Place Of SAM
//  In JAVA and KOTLIN
//    Lambda Expression Can Be Used In Both Java and Kotlin
//    trueButton.setOnClickListener { view : View ->
        trueButton.setOnClickListener {
            Log.d(loggingTAG, "True Button onClicked Called")
            Toast.makeText(this@MainActivity, "Correct Choice!",
                  Toast.LENGTH_SHORT).show()
        }

        class FalseButtonClickHandler : OnClickListener {
            override fun onClick(v: View?) {
                Log.d(loggingTAG, "False Button onClicked Called")
                Toast.makeText(this@MainActivity, "Correct Choice!",
                    Toast.LENGTH_SHORT).show()
            }
        }
        falseButton.setOnClickListener( FalseButtonClickHandler() )

    }
}