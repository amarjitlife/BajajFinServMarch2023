#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

int main() {
	// Spawing New Child Process
	fork();

	printf("Hello World!!! Good Evening!!!...\n");

	char ch = getchar();
	return 0;
}
