
package learnKotlin

fun getLastChar( string: String ) : Char {
	return string.get( string.length -1 )
}

// Extension Function
fun String.lastChar(): Char {
	return this.get( this.length -1 )	
}

// Compiler Will Generate Following Code For You
// fun lastChar( java.lang.String string ) : Char {
// 	return string.get( string.length -1 )	
// } 


val String.lastCharacter: Char
	get() = get(length -1)

var StringBuilder.lastCharacter: Char
	get() = get( length - 1 )
	set( value: Char ) {
		this.setCharAt( length - 1, value )
	}

fun playWithJoinExtensionProperties() {
	println( "Good Morning!".lastCharacter )
	println( "BajajFinServ".lastCharacter )

	val greeting = StringBuilder("Hey#")
	println( greeting.lastCharacter )
	greeting.lastCharacter = '!'
	println( greeting.lastCharacter )
}

fun main() {
	println( getLastChar("Good Morning!") )
	println( "Good Morning!".lastChar() )
}
