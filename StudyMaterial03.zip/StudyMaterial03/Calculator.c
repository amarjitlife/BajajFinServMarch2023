
#include <stdio.h>

// Function Type
//		(int, int) -> int
int sum(int x, int y) { return x + y; }
int sub(int x, int y) { return x - y; }

// Polymorphic Function

// Function Type
//		(int, int, (int, int) -> int ) -> int
int calculator(int x, int y, int (*operation)(int, int) ) {
	return operation(x, y);
}

int main() {
	int a = 100;
	int b = 200;

	int result = 0;

	result = calculator(a, b, sum);
	printf("\nResult : %d", result);

	result = calculator(a, b, sub);
	printf("\nResult : %d", result);	
}

