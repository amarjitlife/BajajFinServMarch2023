
_________________________________________________________________________________________

DAY 01-04
_________________________________________________________________________________________

	Reading Assignment RA1 : Coding, Reading and Thinking Assignment [ MUST MUST ]		
		Kotlin In Action
			Till Generics (Inclusive)

_________________________________________________________________________________________

DAY 05
_________________________________________________________________________________________

	Reading Assignment A1 : Coding, Reading and Thinking Assignment [ MUST MUST ]		
		Kotlin In Action
			Till Generics (Inclusive)
	
	Reading Assignment A2 : Coding, Reading and Thinking Assignment [ MUST MUST ]		
		Coroutines Guide
		Till Channels (Inclusive)

		https://kotlinlang.org/docs/coroutines-guide.html#table-of-contents

	Reading Assignment A3 : Reading and Thinking Assignment [ MUST MUST ]		
		https://developer.android.com/reference/android/content/Intent
		https://developer.android.com/guide/components/intents-filters
		https://developer.android.com/guide/components/fundamentals
		https://developer.android.com/guide/components/activities/activity-lifecycle

_________________________________________________________________________________________

DAY 06
_________________________________________________________________________________________

	Coding Assignment A1 : Coding, Reading and Experimentation Assignment [ MUST MUST ]		
		- Chapter 01 and Chapter 02 : Reading and Coding
		- Solve Challenges Behind Each Chapter
		- Refactor Code To Better Design, Role and Responsibilites
		- Store Questions Data in XML
		- Store Questions Data in JSON		

	Reading Assignment A2 : Coding, Reading and Thinking Assignment [ MUST MUST ]		
		Coroutines Guide
			Do Hands On
		https://kotlinlang.org/docs/coroutines-guide.html#table-of-contents


	Reading Assignment A3 : Reading and Thinking Assignment [ MUST ]		
		https://developer.android.com/reference/android/content/Intent
		https://developer.android.com/guide/components/intents-filters
		https://developer.android.com/guide/components/fundamentals
		https://developer.android.com/guide/components/activities/activity-lifecycle

_________________________________________________________________________________________

DAY 07
_________________________________________________________________________________________

	Coding Assignment A1 : Coding, Reading and Experimentation Assignment [ MUST MUST ]		
		GitHub Link: https://github.com/amarjitlife/BajajFinServJanuary2023
		Reference Material :  StudyMaterial07.zip
			├── AndroidCode
				├── QuizApp03
			└── ReadingGuides
			    └── AndroidExperientationPart02.pdf

		- Chapter 01, Chapter 02, Chapter 03 : Reading and Coding
		- Solve Challenges Behind Each Chapter
		- Refactor Code To Better Design, Role and Responsibilites
		- Store Questions Data in XML
		- Store Questions Data in JSON	
		- Store/Reconstruct Business Logic and/or Application State
		- Create Seperate UI For Landscape and Portrait Mode

	Reading Assignment A2 : Coding, Reading and Thinking Assignment [ MUST MUST ]		
		Coroutines Guide : Do Hands On
			https://kotlinlang.org/docs/coroutines-guide.html#table-of-contents

	Reading Assignment A3 : Reading and Thinking Assignment [ MUST ]		
		https://developer.android.com/reference/android/content/Intent
		https://developer.android.com/guide/components/intents-filters
		https://developer.android.com/guide/components/fundamentals
		https://developer.android.com/guide/components/activities/activity-lifecycle

_________________________________________________________________________________________

DAY 08
_________________________________________________________________________________________

	Coding Assignment A1 : Reading and Experimentation Assignment [ MUST MUST ]		
		GitHub Link: https://github.com/amarjitlife/BajajFinServJanuary2023
		Reference Material :  StudyMaterial08.zip
			└── ReadingGuides
			    └── AndroidExperientationPart02.pdf
			    └── AndroidExperientationPart03.pdf

		- Chapter 01 To Chapter 07 : Reading and Coding

	Coding Assignment A2 : QuizApp Coding Assignment [ MUST MUST ]		

		1. Activity A2: QuizActivityController Shows Two UI 
			viz. MCQQuestionsUI and TrueFalseQuestionsUI
			Implement These Using Indivisual Fragements 

		2. Activity A2: Above Both Fragments Have Common Question Navigation Buttons
			Create A Commomn QuestionsNavigationFragement
			and Use In Above Two Fragemnets

		3. Design Data Communication
			- Unidirectional Communication
			- Bidirectional Communication

			3.1 Between Activity A1 and Activity A2
				Activity A1: StartActivityController 
				Activity A2: QuizActivityControllery 

			3.2 Between Activities and Fragments
			3.3 Between Fragments

		4. Create Two Fragments In Activity A1: StartActivityController
			4.1 ConfigurationFragment and QuizStatisticsFragment

		5. Save Data From Data Models To PersistentStores 
			Create Specialised Classes For JSON, XML, Databases Stores

_________________________________________________________________________________________

DAY 09
_________________________________________________________________________________________


	Coding Assignment A1 : Reading and Experimentation Assignment [ MUST MUST ]		
		GitHub Link: https://github.com/amarjitlife/BajajFinServJanuary2023
		Reference Material :  StudyMaterial08.zip
			└── ReadingGuides
			    └── AndroidExperientationPart02.pdf
			    └── AndroidExperientationPart03.pdf

		- Chapter 01 To Chapter 07 : Reading and Coding

	Coding Assignment A2 : QuizApp Coding Assignment [ MUST MUST ]		

		6. Add Menu In Your App Bar
			Add Two Menu Items viz. Settings and Statistics 
			On Settings Menu Item Selection
				Show SettingsFragment
			On Statistics Menu Item Selection
				Show StatsiticsFragment
	
		7. Activity A1: StartActivityController Will Show
			List Of Subjects/Areas
				Implement Using RecylerView

			On Row Selection In List
				Visit
				Activity A2: QuizActivityControllery 

		8. Add Activity A3: StatisticsListActivity
			List Of All Quizes Attempted
				In Row Show Quiz, Subjects/Area, Score, Percentage

			On Row Selection In List
				Show Attempted Quiz Statistics and Details			

		9. Add Default Settings
			Phase 01
				Quiz Type: MCQ, TrueFalse, Both MCQ and TrueFalse
				MCQType: Only One Choice Right, Or Multiple Choices Right
			
			Phase 02
				Quiz Level: Beginner, Intermediate and Advance
				Age Group: 04 to 06 Years, 06 to 08 Years

_________________________________________________________________________________________
_________________________________________________________________________________________
_________________________________________________________________________________________
_________________________________________________________________________________________

Aniket Gupta
Akash Mishra
Anurag
Atla Naveen		
Dakshendra Singh
Bhagyashree
Shankar
Kalavati HR
Sai Rama

_________________________________________________________________________________________
_________________________________________________________________________________________
_________________________________________________________________________________________
_________________________________________________________________________________________
_________________________________________________________________________________________
_________________________________________________________________________________________
