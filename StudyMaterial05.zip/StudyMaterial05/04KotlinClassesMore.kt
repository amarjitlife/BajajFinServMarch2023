/*
kotlinc 04KotlinClassesMore.kt -include-runtime -d classes.jar
java -jar classes.jar
*/
package learnKotlin

import java.util.HashSet

data class Subject(val name: String, val grade: Char, val points: Double,
				   val credits: Double )

// open class Person(open val firstName: String, open val lastName: String) {
// 	val fullName = "$firstName $lastName"
// 	// fun fullName() = "$firstName $lastName"
// }

// class Student(override val firstName: String, override val lastName: String) : Person(firstName, lastName)

open class Person(val firstName: String, val lastName: String) {
	val fullName = "$firstName $lastName"
	// fun fullName() = "$firstName $lastName"
}

// error: parameters must have type annotation
// class Student(firstName, lastName) : Person(firstName, lastName)
open class Student(firstName: String, lastName: String) : Person(firstName, lastName) {
	val passedSubjects : MutableList<Subject> = mutableListOf<Subject>()
	val failedSubjects : MutableList<Subject> = mutableListOf<Subject>()

	fun recordGrade( subject: Subject ) {
		if ( subject.grade == 'F' ) failedSubjects.add( subject )
		else passedSubjects.add( subject )
	}

	open fun printGrades() {
		for ( subject in passedSubjects ) println("  $subject")
		for ( subject in failedSubjects ) println("  $subject")
	}

	fun isPassed() = failedSubjects.size <= 2
}

fun playWithClassInheritance() {
	val gabbar = Person("Gabbar", "Singh")
	println(gabbar.firstName)
	println(gabbar.lastName)

	val alice = Student("Alice", "Carols")
	println(alice.firstName)
	println(alice.lastName)
}

//_________________________________________________________

fun playWithStudentGrades() {
	val alina = Student("Alina", "Mark")
						// Named Arguments
	val alinaEnglish = Subject(name = "English", grade = 'C', points = 7.0, 
																credits = 3.0 )
	// val alinaEnglish1 = Subject("English", grade = 'C', 7.0, credits = 3.0 )
	val alinaSc = Subject("Science", 'B', points = 8.0, credits = 4.0 )
	val alinaMaths = Subject("Mathematics", 'A', 9.0, 4.0)

	alina.recordGrade( alinaEnglish )
	alina.recordGrade( alinaSc )
	alina.recordGrade( alinaMaths )
	println( alina.fullName )
	alina.printGrades()
	println( "Passed : ${ alina.isPassed() }" )

	val gabbar = Student("Gabbar", "Singh")
	val gabbarDecoit = Subject(name = "Decoit", grade = 'A', points = 10.0, 
															credits = 3.0 )
	val gabbarKidnapping = Subject(name = "Kidnapping", grade = 'A', points = 10.0,
															credits = 4.0 )
	val gabbarShooting = Subject(name = "Shooting", grade = 'A', points = 10.0,
															credits = 4.0 )
	gabbar.recordGrade( gabbarDecoit )
	gabbar.recordGrade( gabbarKidnapping )
	gabbar.recordGrade( gabbarShooting )
	println( gabbar.fullName )
	gabbar.printGrades()

	println( "Passed : ${ gabbar.isPassed() }" )
}


//_________________________________________________________

data class Game(val name: String, val grade: Char, val points: Double)

class StudentAthlete(firstName: String, lastName: String) : Student(firstName, lastName) {
	val gamesPlayed = mutableListOf<Game>()

	fun recordGame(game: Game) = gamesPlayed.add(game)

	override fun printGrades() {
		super.printGrades()
		for( game in gamesPlayed ) println("	$game")
	}
}

fun playWithStudentSportspersons() {
	val alina = StudentAthlete("Alina", "Mark")
						// Named Arguments
	val alinaEnglish = Subject(name = "English", grade = 'C', points = 7.0, 
																credits = 3.0 )
	val alinaSc = Subject("Science", 'B', points = 8.0, credits = 4.0 )
	val alinaMaths = Subject("Mathematics", 'A', 9.0, 4.0)
	val alinaTennis = Game(name = "Tennis", grade = 'A', points = 9.0 )

	alina.recordGrade( alinaEnglish )
	alina.recordGrade( alinaSc )
	alina.recordGrade( alinaMaths )
	alina.recordGame( alinaTennis )
	println( alina.fullName )
	alina.printGrades()
	println( "Passed : ${ alina.isPassed() }" )

	val gabbar = StudentAthlete("Gabbar", "Singh")
	val gabbarDecoit = Subject(name = "Decoit", grade = 'A', points = 10.0, credits = 3.0 )
	val gabbarKidnapping = Subject(name = "Kidnapping", grade = 'A', points = 10.0, credits = 4.0 )
	val gabbarShooting = Game(name = "Shooting", grade = 'A', points = 10.0)
	val gabbarHorseRiding = Game(name = "Horse Riding", grade = 'A', points = 10.0)

	gabbar.recordGrade( gabbarDecoit )
	gabbar.recordGrade( gabbarKidnapping )
	gabbar.recordGame( gabbarShooting )
	gabbar.recordGame( gabbarHorseRiding )

	println( gabbar.fullName )
	gabbar.printGrades()
	println( "Passed : ${ alina.isPassed() }" )
}

//_________________________________________________________

open class BandMember(firstName: String, lastName: String) : Student(firstName, lastName) {
	open val minimumPracticeTime: Int
		get() { return 2 }
}

class GuitarPlayer(firstName: String, lastName: String) : BandMember(firstName, lastName) {
	override val minimumPracticeTime: Int
		get() { return 4 }
}

class FlutePlayer(firstName: String, lastName: String) : BandMember(firstName, lastName) {
	override val minimumPracticeTime: Int
		get() { return 3 }
}

fun playWithRuntimeTypeCheck() {
	val guitarPlayer : GuitarPlayer = GuitarPlayer("Soumyadip", "Sengupta")
	println( guitarPlayer )

	// println( guitarPlayer is GuitarPlayer )
	// println( guitarPlayer is BandMember )
	// println( guitarPlayer is Student )
	// println( guitarPlayer is Person )

	// val refererence1 = guitarPlayer
	// val refererence2 : BandMember 	= guitarPlayer
	// val refererence3 : Student 		= guitarPlayer
	// val refererence4 : Person 		= guitarPlayer

	// println( refererence1 is GuitarPlayer )
	// println( refererence1 is BandMember )
	// println( refererence1 is Student )
	// println( refererence1 is Person )

	// println( refererence2 is GuitarPlayer )
	// println( refererence2 is BandMember )
	// println( refererence2 is Student )
	// println( refererence2 is Person )

	// val sakira = BandMember("Sakira","Nagpal")
	// println( sakira is GuitarPlayer )
	// println( sakira is BandMember )
	// println( sakira is Student )
	// println( sakira is Person )	

	// val milkha = StudentAthlete("Milkha", "Singh")
	// //  error: incompatible types: GuitarPlayer and StudentAthlete
	// // println( milkha is GuitarPlayer )
	// // error: incompatible types: BandMember and StudentAthlete
	// // println( milkha is BandMember )
	// println( milkha is Student )
	// println( milkha is Person )		
}

//_________________________________________________________

abstract class Mammal(val name: String, val birthDate: String) {
	abstract fun consumeFood()
}

class Human(name: String, birthDate: String) : Mammal(name, birthDate) {
	override fun consumeFood() {
		println("Human Consuming Food!...")
	}

	fun createBirthCertificate() = println("Birth Certificate Created!")
}

fun playWithMammals() {
	// val lion = Mammal("Lion", "10-10-10")
	// println(lion)

	val gabbar = Human("Gabbar Singh", "1977")
	gabbar.consumeFood()
	gabbar.createBirthCertificate()
}


//_________________________________________________________

interface Clickable3 {
    fun click()
    fun showOff() = println("I'm clickable!")
}

interface Focusable3 {
    fun setFocus(b: Boolean) =
        println("I ${if (b) "got" else "lost"} focus.")

    fun showOff() = println("I'm focusable!")
}

class Button3 : Clickable3, Focusable3 {
    override fun click() = println("I was clicked")

    override fun showOff() {
        super<Clickable3>.showOff()
        super<Focusable3>.showOff()
    }
}

fun playWithInterfacesAndRuntimeTypeCheck() {
	// val button = Button3()

	// println( button is Button3 )
	// println( button is Clickable3 )
	// println( button is Focusable3 )
}

//_________________________________________________________

sealed class Geometry {
	// Classes Defined Inside Another Class
	class Circle(val radius: Int) : Geometry()
	class Square(val side: Int) : Geometry()
	class Unknown(val size: Int) : Geometry()
}
// DESIGN 1
fun sizeOfGeometry1( geometry: Geometry ) : Any {
	return when( geometry ) {
		is Geometry.Circle -> geometry.radius
		is Geometry.Square -> geometry.side
		else -> "Unknown Shape"
	}
}
// DESIGN 2
fun sizeOfGeometry2( geometry: Geometry ) = when( geometry ) {
	is Geometry.Circle -> geometry.radius
	is Geometry.Square -> geometry.side
	else -> "Unknown Shape"
}

// DESIGN 1 and DESIGN 2 BOTH ARE SAME
// DESIGN 3: BETTER DESIGN
fun sizeOfGeometry3( geometry: Geometry ) : Int = when( geometry ) {
	is Geometry.Circle -> geometry.radius
	is Geometry.Square -> geometry.side
	is Geometry.Unknown -> geometry.size
}

fun playWithGeometries() {
	val circle1 = Geometry.Circle( 10 )
	val circle2 = Geometry.Circle( 20 )
	println( sizeOfGeometry1( circle1 ) )
	println( sizeOfGeometry1( circle2 ) )

	val square1 = Geometry.Square( 11 )
	val square2 = Geometry.Square( 22 )
	println( sizeOfGeometry1( square1 ) )
	println( sizeOfGeometry1( square2 ) )

	println( sizeOfGeometry3( circle1 ) )
	println( sizeOfGeometry3( circle2 ) )
	println( sizeOfGeometry3( square1 ) )
	println( sizeOfGeometry3( square2 ) )

}

//_________________________________________________________
// Primary and Secondary Constructors

// Following Both Classes Definitions Are Equivalent
//					Primary Constructor
class PersonAgain1(val firstName: String, val lastName: String) {
	val fullName = "$firstName $lastName"
}

//					Primary Constructor
class PersonAgain2 constructor(val firstName: String, val lastName: String) {
	val fullName = "$firstName $lastName"
}

fun playWithConstructors() {
	val gabbar = PersonAgain1("Gabbar", "Singh")
	println( gabbar.fullName )

	val gabbarAgain = PersonAgain2("Gabbar", "Singh")
	println( gabbarAgain.fullName )
}

//_________________________________________________________

//				Primary Constructor With Default Arguments
class ShapeAgain(val boundaryColor: String = "Black", var fillColor: String = "Unknown") {
	fun printData() {
		println("ShapeAgain:: BoundryColor=$boundaryColor, FillColor=$fillColor")
	}
}

open class ShapeOnceAgain {
	var boundaryColor: String
	var fillColor : String 

	// Secondary Constructors
	constructor(boundaryColor: String) {
		this.boundaryColor = boundaryColor
		this.fillColor = "Unknown"
	}

	// Secondary Constructors
	// Constructor Overloadings
	constructor(boundaryColor: String, fillColor: String) {
		this.boundaryColor = boundaryColor
		this.fillColor = fillColor
	}
	
	open fun printData() {
		println("ShapeOnceAgain :: BoundryColor=$boundaryColor, FillColor=$fillColor")
	}
}

fun playWithShapeOnceAgain() {
	val shape1 = ShapeOnceAgain("Black")
	shape1.printData()

	val shape2 = ShapeOnceAgain("Black", "Green")
	shape2.printData()
}


//_________________________________________________________

// BEST PRACTICES
//		CONSTRUCTOR DESIGN BEST PRACTICES
//		 	All The Constructors In A Class Should Call Designated Constructor In Same Class
//				i.e. Designated Constructor : Constructor Taking Maximum Number Of Arguments
//			All The Designated Constructor Should Call Designated Constructors In Parent Class

class CircleOnceAgain : ShapeOnceAgain {
	var radius: Int

	// error: explicit 'this' or 'super' call is required. 
	// There is no constructor in superclass that can be called without arguments
	// constructor(boundaryColor: String) {
	constructor(boundaryColor: String) : this(boundaryColor, "Unknown", 0){
		this.boundaryColor = boundaryColor
		this.fillColor = "Unknown"
		this.radius = 0
	}

	// error: explicit 'this' or 'super' call is required. 
	// There is no constructor in superclass that can be called without arguments
	// constructor(boundaryColor: String, fillColor: String, radius: Int) {
	constructor(boundaryColor: String, fillColor: String, radius: Int) : super(boundaryColor, fillColor) {
		this.boundaryColor = boundaryColor
		this.fillColor = fillColor
		this.radius = radius
	}

	override fun printData() {
		println("CircleOnceAgain :: BoundryColor=$boundaryColor, FillColor=$fillColor, Radius=$radius")
	}
}

fun playWithShapeOnceAgainAndCircleOnceAgain() {
	val circle1 = CircleOnceAgain("Black")
	circle1.printData()

	val circle2 = CircleOnceAgain("Black", "Green", 100)
	circle2.printData()
}

//_________________________________________________________

fun playWithLocalFunctionsAndClasses() { // Outside/Enclosing Functon/Context
	var something = 10

	// Local Function
	//		Function Defined Inside Function
	//		doSomething Is Local Function
	fun doSomething() { // Inside/Enclosed Function/Context
		println("Local Function doSomething Called!")
		println("Accessing something Inside Local Function: $something")
		something = 1111
	
		var somethingInsideLocal = 100
		println(somethingInsideLocal)
	}

	println("Accessing something Outside Local Function: $something")
	// println("Accessing somethingInsideLocal Outside Local Function: $somethingInsideLocal")

	// Local Classes
	//		Class Defined Inside Function
	//		Person Is Local Class To Function

	//Inside Class/Context
	class Person(val name: String) { // Inside/Enclosed Context
		val somethingAgain = something + 100

		fun doDance() = println("$name Doing Dance...")
		fun doSomething() {
			println("Accessing Inside Person : $somethingAgain")
			something = somethingAgain
		}
	}

	doSomething()
	println("Accessing something In Outside Context: $something")

	val person = Person("Gabbar Singh")
	println( person.name )
	person.doDance()
	person.doSomething()

	println("Accessing something In Outside Context: $something")
}


//_________________________________________________________

data class Privilege( val id: Int, val name: String )
// Property Visibility
//     Default Visibility Is Public i.e. Accessible Inside and Outside Of Defining Class
//     Private Visibility Accessible Only Inside Defining Class
//     Protected Visibility Accessible Inside Defining Class And Child Classes Of It
open class User(val firstName: String, val lastName: String, protected var age: Int, private var aadharCard: Int ) 

class PrivilegedUser(firstName: String, lastName: String, age: Int, aadharCard: Int) : User(firstName, lastName, age, aadharCard) {
    // Private To PrivilegeUser Class Only
    //      Cann't Be Accessed Outside Using Object Of PrivilegeUser Class
    private val privileges = mutableListOf<Privilege>()

    fun addPrivilege(privilege: Privilege) {
        privileges.add( privilege )
    }

    fun printPrivileges() {
        for ( privilege in privileges ) {
            println( "    $privilege" )
        }
    }

    fun details() : String {
        // error: cannot access 'aadharCard': 
        // it is invisible (private in a supertype) in 'PrivilegedUser'
        // return "$firstName $lastName $aadharCard"

        return "Name : $firstName $lastName, Age: $age"
    }
}

fun playWithPrivilegedUser() {
    val privilegedUser = PrivilegedUser(firstName = "Alice", lastName = "Carols", age = 21, aadharCard = 9999 )
    val invisiblePrivilege = Privilege( id = 11, name = "Can Become Invisible")
    val immortalPrivilege  = Privilege( id = 22, name = "Can Become Immortal")
    privilegedUser.addPrivilege( invisiblePrivilege )
    privilegedUser.addPrivilege( immortalPrivilege )
    println( privilegedUser.details() )
    privilegedUser.printPrivileges()
    // println( privilegedUser.privileges )
    // privilegedUser.privileges.add( Privilege( -99, "Something Useless Power"))
    // println( privilegedUser.privileges )
}

//_________________________________________________________

// In Java 
//		Class Inside Class Are Made Using static Keyword
// In Kotlin
//		Class Inside Class Are Nested By Default
class Car(val carName: String) { // Outer Class/Context
	val steering: Int = 0

	// Definining Class Inside Class
	//		In Kotlin By Default Nested Class
	//		Nested Classes
	//			Inside Class/Context CAN'T Access Outside Class/Context
	class Engine(val engineName: String) { //Inside Class/Context
		override fun toString() : String {
			// error: unresolved reference: carName
			// return "Car Have Engine: $engineName In Car : $carName"			
			return "Car Have Engine: $engineName"
		}
	}
}

// In Java 
//		Class Inside Class Are Inner By Default
// In Kotlin : Inner Classes
//		Class Inside Class Made Inner By Using inner Keyword
class CarAgain(val carName: String) { // Outer Class/Context
	val steering: Int = 0

	// Definining Class Inside Class
	//		In Kotlin By Default Nested Class
	//		Nested Classes
	//			Inside Class/Context CAN Access Outside Class/Context
	inner class Engine(val engineName: String) { //Inside Class/Context
		override fun toString() : String {
			// error: unresolved reference: carName
			return "Car Have Engine: $engineName In Car : $carName"			
			// return "Car Have Engine: $engineName"
		}
	}
}

fun playWithNestedAndInnerClasses() {
	val harrier = Car("Harrier")
	val harrierEngine = Car.Engine("V12")

	println( harrier.carName )
	println( harrierEngine )

	val swift = CarAgain("Swift Dzire")
	val swiftEngine = swift.Engine("Fiat")

	println( swiftEngine )
}

//_________________________________________________________

//import java.util.HashSet

class CountingSet<T>( val innerSet: MutableCollection<T> = HashSet<T>() ) : MutableCollection<T> by innerSet {

    var objectsAdded = 0

    override fun add(element: T): Boolean {
        objectsAdded++
        return innerSet.add(element)
    }

    override fun addAll(elements: Collection<T>): Boolean {
        objectsAdded += elements.size
        return innerSet.addAll(elements)
    }
}

fun classDelegationUsingTheByKeyword() {
    val countingSet = CountingSet<Int>()
    countingSet.addAll(listOf(1, 1, 2))
    println("${countingSet.objectsAdded} objects were added, ${countingSet.size} remain")
}

//_________________________________________________________

// Benifits Of Interfaces
// Using by Keyword
// Sealed Classes One More Example

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________


fun main() {
	println("\nFunction : playWithClassInheritance")
	playWithClassInheritance()

	println("\nFunction : playWithStudentGrades")
	playWithStudentGrades()

	println("\nFunction : playWithStudentSportspersons")
	playWithStudentSportspersons()

	println("\nFunction : playWithRuntimeTypeCheck")
	playWithRuntimeTypeCheck()

	println("\nFunction : playWithMammals")
	playWithMammals()

	println("\nFunction : playWithInterfacesAndRuntimeTypeCheck")
	playWithInterfacesAndRuntimeTypeCheck()

	println("\nFunction : playWithGeometries")
	playWithGeometries()

	println("\nFunction : playWithConstructors")
	playWithConstructors()

	println("\nFunction : playWithShapeOnceAgain")
	playWithShapeOnceAgain()

	println("\nFunction : playWithLocalFunctionsAndClasses")
	playWithLocalFunctionsAndClasses()

	println("\nFunction : playWithPrivilegedUser")
	playWithPrivilegedUser()

	println("\nFunction : playWithNestedAndInnerClasses")
	playWithNestedAndInnerClasses()

	println("\nFunction : classDelegationUsingTheByKeyword")
	classDelegationUsingTheByKeyword()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}
