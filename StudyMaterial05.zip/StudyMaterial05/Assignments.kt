
_________________________________________________________________________________________

DAY 01-04
_________________________________________________________________________________________

	Reading Assignment RA1 : Coding, Reading and Thinking Assignment [ MUST MUST ]		
		Kotlin In Action
			Till Generics (Inclusive)

_________________________________________________________________________________________

DAY 05
_________________________________________________________________________________________

	Reading Assignment A1 : Coding, Reading and Thinking Assignment [ MUST MUST ]		
		Kotlin In Action
			Till Generics (Inclusive)
	
	Reading Assignment A2 : Coding, Reading and Thinking Assignment [ MUST MUST ]		
		Coroutines Guide
		Till Channels (Inclusive)

		https://kotlinlang.org/docs/coroutines-guide.html#table-of-contents

	Reading Assignment A3 : Reading and Thinking Assignment [ MUST MUST ]		
		https://developer.android.com/reference/android/content/Intent
		https://developer.android.com/guide/components/intents-filters
		https://developer.android.com/guide/components/fundamentals
		https://developer.android.com/guide/components/activities/activity-lifecycle

_________________________________________________________________________________________

DAY 06
_________________________________________________________________________________________

	Coding Assignment A1 : Coding, Reading and Experimentation Assignment [ MUST MUST ]		
		- Chapter 01 and Chapter 02 : Reading and Coding
		- Solve Challenges Behind Each Chapter
		- Refactor Code To Better Design, Role and Responsibilites
		- Store Questions Data in XML
		- Store Questions Data in JSON		

	Reading Assignment A2 : Coding, Reading and Thinking Assignment [ MUST MUST ]		
		Coroutines Guide
			Do Hands On
		https://kotlinlang.org/docs/coroutines-guide.html#table-of-contents


	Reading Assignment A3 : Reading and Thinking Assignment [ MUST ]		
		https://developer.android.com/reference/android/content/Intent
		https://developer.android.com/guide/components/intents-filters
		https://developer.android.com/guide/components/fundamentals
		https://developer.android.com/guide/components/activities/activity-lifecycle

_________________________________________________________________________________________
_________________________________________________________________________________________
_________________________________________________________________________________________
_________________________________________________________________________________________
_________________________________________________________________________________________
_________________________________________________________________________________________
_________________________________________________________________________________________
_________________________________________________________________________________________
_________________________________________________________________________________________
_________________________________________________________________________________________
_________________________________________________________________________________________
